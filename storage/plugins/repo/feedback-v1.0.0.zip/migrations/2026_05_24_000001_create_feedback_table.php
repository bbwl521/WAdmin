<?php

declare(strict_types=1);

use Hyperf\Database\Migrations\Migration;
use Hyperf\Database\Schema\Blueprint;
use Hyperf\Database\Schema\Schema;

class CreateFeedbackTable extends Migration
{
    public function up(): void
    {
        Schema::create('feedback', static function (Blueprint $table) {
            $table->comment('意见反馈表');
            $table->bigIncrements('id')->comment('主键');
            $table->string('title', 100)->comment('反馈标题');
            $table->text('content')->comment('反馈内容');
            $table->string('type', 20)->default('suggestion')->comment('类型: suggestion=建议, bug=缺陷, other=其他');
            $table->string('contact', 100)->default('')->comment('联系方式');
            $table->string('status', 20)->default('pending')->comment('状态: pending=待处理, processing=处理中, resolved=已解决, closed=已关闭');
            $table->string('reply', 500)->default('')->comment('回复内容');
            $table->bigInteger('created_by')->default(0)->comment('提交人ID');
            $table->datetimes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('feedback');
    }
}
