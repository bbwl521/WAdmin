<?php

declare(strict_types=1);

namespace Plugin\Feedback\Service;

use Plugin\Feedback\Model\Feedback;
use Hyperf\DbConnection\Db;

final class FeedbackService
{
    /** @return array{items: Feedback[], total: int} */
    public function list(array $params = []): array
    {
        $page = (int) ($params['page'] ?? 1);
        $pageSize = (int) ($params['page_size'] ?? 15);

        $query = Feedback::query()
            ->when(($params['type'] ?? '') !== '', fn ($q) => $q->where('type', $params['type']))
            ->when(($params['status'] ?? '') !== '', fn ($q) => $q->where('status', $params['status']))
            ->orderBy('id', 'desc');

        $total = (int) $query->count();
        $items = $query->forPage($page, $pageSize)->get();

        return ['items' => $items, 'total' => $total];
    }

    public function create(array $data): Feedback
    {
        return Feedback::create([
            'title' => $data['title'],
            'content' => $data['content'],
            'type' => $data['type'] ?? 'suggestion',
            'contact' => $data['contact'] ?? '',
            'status' => 'pending',
            'created_by' => $data['created_by'] ?? 0,
        ]);
    }

    public function update(int $id, array $data): Feedback
    {
        $feedback = Feedback::query()->findOrFail($id);

        $feedback->update(array_intersect_key($data, array_flip([
            'status', 'reply',
        ])));

        return $feedback->refresh();
    }

    public function delete(int $id): void
    {
        Feedback::query()->where('id', $id)->delete();
    }
}
