<?php

declare(strict_types=1);

namespace Plugin\Feedback;

use App\Plugin\Contract\PluginInterface;

final class Plugin implements PluginInterface
{
    public function onInstall(): void
    {
    }

    public function onUninstall(): void
    {
    }

    public function onUpgrade(): void
    {
    }

    public function onBeforeUpgrade(): void
    {
    }

    public function onEnable(): void
    {
    }

    public function onDisable(): void
    {
    }
}
