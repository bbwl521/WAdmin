<?php

declare(strict_types=1);

namespace Plugin\Feedback\Model;

use Carbon\Carbon;
use Hyperf\DbConnection\Model\Model as MineModel;

/**
 * @property int $id 主键
 * @property string $title 反馈标题
 * @property string $content 反馈内容
 * @property string $type 类型: suggestion/bug/other
 * @property string $contact 联系方式
 * @property string $status 状态: pending/processing/resolved/closed
 * @property string $reply 回复内容
 * @property int $created_by 提交人ID
 * @property Carbon $created_at
 * @property Carbon $updated_at
 */
final class Feedback extends MineModel
{
    protected ?string $table = 'feedback';

    protected array $fillable = [
        'title', 'content', 'type', 'contact', 'status', 'reply', 'created_by',
    ];

    protected array $casts = [
        'id' => 'integer',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}
