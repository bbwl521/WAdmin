<?php

declare(strict_types=1);

namespace Plugin\Feedback\Controller;

use App\Http\Common\Controller\AbstractController;
use App\Http\Common\Result;
use Hyperf\HttpServer\Contract\RequestInterface;
use Plugin\Feedback\Service\FeedbackService;

final class FeedbackController extends AbstractController
{
    public function __construct(
        private readonly FeedbackService $service,
        private readonly RequestInterface $request,
    ) {}

    public function index(): Result
    {
        $params = $this->request->all();
        $result = $this->service->list($params);

        return $this->success([
            'items' => $result['items']->toArray(),
            'total' => $result['total'],
        ]);
    }

    public function store(): Result
    {
        $data = $this->request->all();

        if (empty($data['title']) || empty($data['content'])) {
            return $this->error('标题和内容不能为空');
        }

        $feedback = $this->service->create($data);

        return $this->success($feedback->toArray());
    }

    public function update(int $id): Result
    {
        $data = $this->request->all();

        $feedback = $this->service->update($id, $data);

        return $this->success($feedback->toArray());
    }

    public function destroy(int $id): Result
    {
        $this->service->delete($id);

        return $this->success(['message' => '删除成功']);
    }
}
