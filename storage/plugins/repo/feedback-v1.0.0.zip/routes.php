<?php

declare(strict_types=1);

return [
    ['GET',    '/admin/feedback',         'Plugin\Feedback\Controller\FeedbackController@index'],
    ['POST',   '/admin/feedback',         'Plugin\Feedback\Controller\FeedbackController@store'],
    ['PUT',    '/admin/feedback/{id}',    'Plugin\Feedback\Controller\FeedbackController@update'],
    ['DELETE', '/admin/feedback/{id}',    'Plugin\Feedback\Controller\FeedbackController@destroy'],
];
